<?php
session_start();


include_once('init.php');


//admin yönlendirme
if (isset($_SESSION['username'])) {
    header("Location: admin.php");
    exit();
}


// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Şifreyi hash'liyoruz

    // formdan gelen veriyi mysql de sorguluyoruz
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($sqlConnect, $sql);

    // yönlendirme veya hata mesajı
    if (mysqli_num_rows($result) == 1) {
        $_SESSION['username'] = $username;
        header("Location: admin.php");
    } else {
        echo "Yanlış kullanıcı adı veya şifre!";
    }
}

mysqli_close($sqlConnect);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .login-container label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Girişi</h2>
        <form method="post" action="login.php">
            <label for="username" >Kullanıcı Adı:</label>
            <input type="text" id="username" name="username"placeholder="esra_aytac" required>
            <label for="password" >Şifre:</label>
            <input type="password" id="password" name="password" placeholder="123456" required>
            <input type="submit" value="Giriş">
        </form>
    </div>
</body>
</html>