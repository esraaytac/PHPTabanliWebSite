<?php

if(empty($_GET['id']) || !is_numeric($_GET['id'])){
    die();
}else {
    $id = $_GET['id'];
}


$sql_query_one = mysqli_query($sqlConnect, "SELECT * FROM projects WHERE `id` = '$id'");
if (mysqli_num_rows($sql_query_one)) {
    $fetched_data = mysqli_fetch_assoc($sql_query_one);
}else {
    echo 'Böyle bir proje yok';
    exit;
}


$alert='';
// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    // bir sorun olduğunda alert değişkenin içine atıyoruz
    if(empty($_POST['project_name'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Proje adı boş bırakılamaz</div>';
    }


    // eğer herhangi bir sorun yoksa alert değişkeni boş olacak ve işlemin geri kalanını yapabileceğiz.
    if(empty($alert)){

        $project_name = trim($_POST['project_name']);

        if(isset($_FILES["project_cover"]) && $_FILES["project_cover"]["error"] == UPLOAD_ERR_OK){
            $project_cover = uploadImage($_FILES["project_cover"]);
            $query  = mysqli_query($sqlConnect, "Update projects set project_cover='$project_cover' WHERE id = $id");
        }


        $query  = mysqli_query($sqlConnect, "Update projects set project_name='$project_name' WHERE id = $id");
        if ($query) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Proje Güncellendi</div>';
        }else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Veri güncellenemedi,</div>'.$sqlConnect->error;
        }


    }

}

echo $alert;

?>


<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Proje Düzenle</h5>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="project_name" class="form-control" id="floatingInput" placeholder="Proje Adı" value="<?= $fetched_data['project_name'] ?>">
                            <label for="floatingInput">Proje Adı</label>
                        </div>

                        <div class="mb-3">
                            <label for="formFile" class="form-label">Kapak Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="project_cover" >
                        </div>
                        <button class="btn btn-danger" type="submit">Güncelle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
