<?php




$alert = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $personal_id = $_POST['personal_id'];

    $query_one     = "DELETE FROM employees WHERE `id` = '$personal_id'";
    $sql_query_one = mysqli_query($sqlConnect, $query_one);

    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Çalışan Silindi</div>';
}

echo $alert;

?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Çalışan Adı</th>
                    <th scope="col">Pozisyonu</th>
                    <th scope="col">Foto</th>
                    <th scope="col">İşlem</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $data = GetEmployees();
                if(!is_null($data)){


                    for ($i = 0; $i < count($data); $i++) {
                        $image = $data[$i]['employee_pp'];
                        $image = './'.$image;


                    ?>
                    <tr>
                        <th scope="row"><?= $i+1; ?></th>
                        <td><?= $data[$i]['employee_name'] ?></td>
                        <td><?= $data[$i]['employee_pos'] ?></td>
                        <td><img src="<?= $image ?>" width="50px"></td>
                        <td>
                            <div class="row">
                                <div class="col">
                                    <a href="?page=edit-personal&id=<?= $data[$i]['id'] ?>" class="btn btn-danger btn-sm">Düzenle</a>
                                </div>
                                <div class="col">
                                    <form action="" method="post">
                                        <input type="hidden" value="<?= $data[$i]['id'] ?>" name="personal_id">
                                        <button class="btn btn-danger btn-sm">Sil</button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php
                    }
                }?>
                </tbody>
            </table>
        </div>
    </div>
</div>