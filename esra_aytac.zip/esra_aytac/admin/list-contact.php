<?php




$alert = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $contact_id = $_POST['contact_id'];

    $query_one     = "DELETE FROM contacts WHERE `id` = '$contact_id'";
    $sql_query_one = mysqli_query($sqlConnect, $query_one);

    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Mesaj Silindi</div>';
}

echo $alert;

?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">İsim</th>
                    <th scope="col">Mail</th>
                    <th scope="col">Konu</th>
                    <th scope="col">İçerik</th>
                    <th scope="col">İşlem</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $data = GetContacts();
                if(!is_null($data)){


                    for ($i = 0; $i < count($data); $i++) {


                        ?>
                        <tr>
                            <th scope="row"><?= $i+1; ?></th>
                            <td><?= $data[$i]['name'] ?></td>
                            <td><?= $data[$i]['email'] ?></td>
                            <td><?= $data[$i]['subject'] ?></td>
                            <td><?= $data[$i]['comment'] ?></td>
                            <td>
                                <form action="" method="post">
                                    <input type="hidden" value="<?= $data[$i]['id'] ?>" name="contact_id">
                                    <button class="btn btn-danger btn-sm">Sil</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                }?>
                </tbody>
            </table>
        </div>
    </div>
</div>