<?php

if(empty($_GET['id']) || !is_numeric($_GET['id'])){
    die();
}else {
    $id = $_GET['id'];
}


$sql_query_one = mysqli_query($sqlConnect, "SELECT * FROM employees WHERE `id` = '$id'");
if (mysqli_num_rows($sql_query_one)) {
    $fetched_data = mysqli_fetch_assoc($sql_query_one);
}else {
    echo 'Böyle bir çalışan yok';
    exit;
}


$alert='';
// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // bir sorun olduğunda alert değişkenin içine atıyoruz
    if(empty($_POST['personal_name'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel adı boş bırakılamaz</div>';
    }

    if(empty($_POST['personal_poss'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel iş boş bırakılamaz</div>';
    }

    if(empty($_POST['personal_about'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel hakkında boş bırakılamaz</div>';
    }


    // eğer herhangi bir sorun yoksa alert değişkeni boş olacak ve işlemin geri kalanını yapabileceğiz.
    if(empty($alert)){

        $personal_name = trim($_POST['personal_name']);
        $personal_poss = trim($_POST['personal_poss']);
        $personal_about = trim($_POST['personal_about']);
        $priority = trim($_POST['personal_sirasi']);

        if(isset($_FILES["personel_pp"]) && $_FILES["personel_pp"]["error"] == UPLOAD_ERR_OK){
            $project_cover = uploadImage($_FILES["personel_pp"]);
            $query  = mysqli_query($sqlConnect, "Update employees set employee_pp='$project_cover' WHERE id = $id");
        }


        $query  = mysqli_query($sqlConnect, "Update employees set employee_name='$personal_name', employee_pos='$personal_poss', employee_about='$personal_about' , priority='$priority' WHERE id = $id");
        if ($query) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Personel Güncellendi</div>';
        }else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Veri güncellenemedi,</div>'.$sqlConnect->error;
        }


    }
}
echo $alert;
?>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Personel Düzenle</h5>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_name" class="form-control" id="floatingInput" placeholder="Personel Adı" value="<?= $fetched_data['employee_name'] ?>">
                            <label for="floatingInput">Personel Adı</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_poss" class="form-control" id="floatingInput" placeholder="Personel Pozisyonu" value="<?= $fetched_data['employee_pos'] ?>">
                            <label for="floatingInput">Personel Pozisyonu</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_about" class="form-control" id="floatingInput" placeholder="Personel Hakkında" value="<?= $fetched_data['employee_about'] ?>">
                            <label for="floatingInput">Personel Hakkında</label>
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="personel_pp" >
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_sirasi" class="form-control" id="floatingInput" placeholder="Personel Sırası" value="<?= $fetched_data['priority'] ?>">
                            <label for="floatingInput">Sırası</label>
                        </div>
                        <button class="btn btn-danger" type="submit">Güncelle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>