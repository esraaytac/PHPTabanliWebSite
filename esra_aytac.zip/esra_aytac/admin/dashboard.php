<?php
$alert='';
// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Kaydedildi</div>';

    $firma_kisaltmasi = $_POST['firma_kisaltmasi'];
    $firma_is = $_POST['firma_org'];
    $about = $_POST['about'];
    $footer_text = $_POST['footer_text'];

    UpdateConfig('about', $about);
    UpdateConfig('firma_org', $firma_is);
    UpdateConfig('firma_kisaltmasi', $firma_kisaltmasi);
    UpdateConfig('footer_text', $footer_text);

    if(isset($_FILES["firma_cover"]) && $_FILES["firma_cover"]["error"] == UPLOAD_ERR_OK){
        $firma_cover = uploadImage($_FILES["firma_cover"]);
        UpdateConfig('firma_cover', $firma_cover);
    }

    if(isset($_FILES["footer_cover"]) && $_FILES["footer_cover"]["error"] == UPLOAD_ERR_OK){

        $footer_cover = uploadImage($_FILES["footer_cover"]);
        UpdateConfig('footer_cover', $footer_cover);
    }
}

echo $alert;

?>


<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Ayarlar</h5>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="firma_kisaltmasi" class="form-control" id="floatingInput" placeholder="Firma Kısaltması" value="<?= GetConfig('firma_kisaltmasi')['value'] ?>">
                            <label for="floatingInput">Firma Kısaltması</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="firma_org" class="form-control" id="floatingInput" placeholder="Firma İş" value="<?= GetConfig('firma_org')['value'] ?>">
                            <label for="floatingInput">Firma İş</label>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" name="about" placeholder="Firma hakkında" id="floatingTextarea2" style="height: 100px"><?= GetConfig('about')['value'] ?></textarea>
                            <label for="floatingTextarea2">Firma Hakkında</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="footer_text" class="form-control" id="floatingInput" placeholder="Firma İş" value="<?= GetConfig('footer_text')['value'] ?>">
                            <label for="floatingInput">Footer Yazı</label>
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Kapak Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="firma_cover" >
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Alt Kısım Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="footer_cover" >
                        </div>
                        <button class="btn btn-danger" type="submit">Kaydet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>