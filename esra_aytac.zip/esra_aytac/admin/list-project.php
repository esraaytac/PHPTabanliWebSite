<?php

$data = GetProjects();

$alert = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $project_id = $_POST['project_id'];

    $query_one     = "DELETE FROM projects WHERE `id` = '$project_id'";
    $sql_query_one = mysqli_query($sqlConnect, $query_one);

    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Proje Silindi</div>';
}

echo $alert;

?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Proje Adı</th>
                    <th scope="col">Resim</th>
                    <th scope="col">İşlem</th>
                </tr>
                </thead>
                <tbody>
                <?php for ($i = 0; $i < count($data); $i++) {
                    $image = $data[$i]['project_cover'];
                    $image = './'.$image;
                    ?>
                <tr>
                    <th scope="row"><?= $i+1; ?></th>
                    <td><?= $data[$i]['project_name'] ?></td>
                    <td><img src="<?= $image ?>" width="50px"></td>
                    <td>
                        <div class="row">
                            <div class="col">
                                <a href="?page=edit-project&id=<?= $data[$i]['id'] ?>" class="btn btn-danger btn-sm">Düzenle</a>
                            </div>
                            <div class="col">
                                <form action="" method="post">
                                    <input type="hidden" value="<?= $data[$i]['id'] ?>" name="project_id">
                                    <button class="btn btn-danger btn-sm">Sil</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>