<?php
$alert='';
// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    // bir sorun olduğunda alert değişkenin içine atıyoruz
    if(empty($_POST['project_name'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Proje adı boş bırakılamaz</div>';
    }

    if(!isset($_FILES["project_cover"])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Proje resmi boş bırakılamaz</div>';
    }



    // eğer herhangi bir sorun yoksa alert değişkeni boş olacak ve işlemin geri kalanını yapabileceğiz.
    if(empty($alert)){

        $project_name = trim($_POST['project_name']);

        if(isset($_FILES["project_cover"]) && $_FILES["project_cover"]["error"] == UPLOAD_ERR_OK){
            $project_cover = uploadImage($_FILES["project_cover"]);
        }


        $query  = mysqli_query($sqlConnect, "INSERT INTO projects (project_name,project_cover) VALUES ('$project_name','$project_cover')");
        if ($query) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Proje Eklendi</div>';
        }else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Veri eklenemedi,</div>'.$sqlConnect->error;
        }


    }

}

echo $alert;

?>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Proje Ekle</h5>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="project_name" class="form-control" id="floatingInput" placeholder="Proje Adı">
                            <label for="floatingInput">Proje Adı</label>
                        </div>

                        <div class="mb-3">
                            <label for="formFile" class="form-label">Kapak Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="project_cover" >
                        </div>
                        <button class="btn btn-danger" type="submit">Ekle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>