<?php
$alert='';
// form gönderilmiş mi kontrol ediyoruz
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    // bir sorun olduğunda alert değişkenin içine atıyoruz
    if(empty($_POST['personal_name'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel adı boş bırakılamaz</div>';
    }

    if(empty($_POST['personal_poss'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel pozisyonu boş bırakılamaz</div>';
    }

    if(empty($_POST['personal_about'])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel hakkında boş bırakılamaz</div>';
    }

    if(!isset($_FILES["personel_pp"])){
        $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Personel resmi boş bırakılamaz</div>';
    }



    // eğer herhangi bir sorun yoksa alert değişkeni boş olacak ve işlemin geri kalanını yapabileceğiz.
    if(empty($alert)){

        $personal_name = trim($_POST['personal_name']);
        $personal_poss = trim($_POST['personal_poss']);
        $personal_about = trim($_POST['personal_about']);

        if(isset($_FILES["personel_pp"]) && $_FILES["personel_pp"]["error"] == UPLOAD_ERR_OK){
            $personal_pp = uploadImage($_FILES["personel_pp"]);
        }


        $query  = mysqli_query($sqlConnect, "INSERT INTO employees (employee_name,employee_pos,employee_about,employee_pp) VALUES ('$personal_name','$personal_poss','$personal_about','$personal_pp')");
        if ($query) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Çalışan Eklendi</div>';
        }else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Veri eklenemedi,</div>'.$sqlConnect->error;
        }


    }

}

echo $alert;

?>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Personel Ekle</h5>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_name" class="form-control" id="floatingInput" placeholder="Personel Adı">
                            <label for="floatingInput">Personel Adı</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_poss" class="form-control" id="floatingInput" placeholder="Personel Pozisyonu">
                            <label for="floatingInput">Personel Pozisyonu</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="personal_about" class="form-control" id="floatingInput" placeholder="Personel Hakkında">
                            <label for="floatingInput">Personel Hakkında</label>
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Fotoğrafı</label>
                            <input class="form-control" type="file" id="formFile" name="personel_pp" >
                        </div>
                        <button class="btn btn-danger" type="submit">Ekle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>