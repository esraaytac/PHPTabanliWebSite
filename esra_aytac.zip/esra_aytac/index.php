<?php

include_once('init.php');

$firma_kisatlmasi = GetConfig('firma_kisaltmasi')['value'];
$firma_org = GetConfig('firma_org')['value'];
$title = $firma_kisatlmasi.' '.$firma_org;
$projects = GetProjects();
$employees = GetEmployees();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $title ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
    <div class="w3-bar w3-white w3-wide w3-padding w3-card">
        <a href="#home" class="w3-bar-item w3-button"><b><?= $firma_kisatlmasi ?></b> <?= $firma_org ?></a>
        <!-- Float links to the right. Hide them on small screens -->
        <div class="w3-right w3-hide-small">
            <a href="#projects" class="w3-bar-item w3-button">Projeler</a>
            <a href="#about" class="w3-bar-item w3-button">Hakkında</a>
            <a href="#contact" class="w3-bar-item w3-button">Iletişim</a>
        </div>
    </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
    <img class="w3-image" src="<?= GetConfig('firma_cover')['value'] ?>" alt="<?= $firma_org ?>" width="1500" height="800">
    <div class="w3-display-middle w3-margin-top w3-center">
        <h1 class="w3-xxlarge w3-text-white"><span class="w3-padding w3-black w3-opacity-min"><b><?= $firma_kisatlmasi ?></b></span> <span class="w3-hide-small w3-text-light-grey"><?= $firma_org ?></span></h1>
    </div>
</header>

<!-- Page content -->
<div class="w3-content w3-padding" style="max-width:1564px">

    <!-- Project Section -->
    <div class="w3-container w3-padding-32" id="projects">
        <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Projeler</h3>
    </div>


    <div class="w3-row-padding">
        <?php for ($i = 0; $i < count($projects); $i++) {
        $image = $projects[$i]['project_cover'];
        $image = './'.$image;
        ?>
        <div class="w3-col l3 m6 w3-margin-bottom">
            <div class="w3-display-container">
                <div class="w3-display-topleft w3-black w3-padding"><?= $projects[$i]['project_name'] ?></div>
                <img src="<?= $image ?>" alt="<?= $projects[$i]['project_name'] ?>" style="width:100%">
            </div>
        </div>
        <?php } ?>
    </div>



    <!-- About Section -->
    <div class="w3-container w3-padding-32" id="about">
        <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Hakkında</h3>
        <p><?= GetConfig('about')['value'] ?>
        </p>
    </div>

    <div class="w3-row-padding w3-grayscale">
        <?php for ($i = 0; $i < count($employees); $i++) {
            $image = $employees[$i]['employee_pp'];
            $image = './'.$image;
            ?>
        <div class="w3-col l3 m6 w3-margin-bottom">
            <img src="<?= $image ?>" alt="John" style="width:100%">
            <h3><?= $employees[$i]['employee_name'] ?></h3>
            <p class="w3-opacity"><?= $employees[$i]['employee_pos'] ?></p>
            <p><?= $employees[$i]['employee_about'] ?></p>
            <p><button class="w3-button w3-light-grey w3-block">İletişim</button></p>
        </div>
        <?php } ?>
    </div>

    <?php
    $alert = '';
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        include_once('init.php');

        $name= trim($_POST['name']);
        $email = trim($_POST['email']);
        $subject = trim($_POST['subject']);
        $comment = trim($_POST['comment']);

        $query  = mysqli_query($sqlConnect, "INSERT INTO contacts (name,email,subject,comment) VALUES ('$name','$email','$subject','$comment')");
        if ($query) {
            $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">Mesajınız gönderilmiştir.</div>';
        }else {
            $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Bir sorun oluştu, lütfen daha sorna tekrar deneyin.</div>';
        }


    }

    ?>
    <!-- Contact Section -->
    <div class="w3-container w3-padding-32" id="contact">
        <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">İletişim</h3>
        <p>Proje Hakkında Bilgi Almak İçin İletişime Geçiniz.</p>
        <form action="" method="post" >
            <input class="w3-input w3-border"  type="text" placeholder="İsim" required name="name">
            <input class="w3-input w3-section w3-border" type="text" placeholder="Email" required name="email">
            <input class="w3-input w3-section w3-border" type="text" placeholder="Konu" required name="subject">
            <input class="w3-input w3-section w3-border" type="text" placeholder="Mesaj" required name="comment">
            <button class="w3-button w3-black w3-section" type="submit">
                <i class="fa fa-paper-plane"></i> MESAJ GÖNDER
            </button>
        </form>
        <?=   $alert; ?>
    </div>

    <!-- Image of location/map -->
    <div class="w3-container">
        <img src="<?= GetConfig('footer_cover')['value'] ?>" class="w3-image" style="width:100%">
    </div>

    <!-- End page content -->
</div>


<!-- Footer -->
<footer class="w3-center w3-black w3-padding-16">
    <p><?= GetConfig('footer_text')['value'] ?></p>
</footer>

</body>
</html>