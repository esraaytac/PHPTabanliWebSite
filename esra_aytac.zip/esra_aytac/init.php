<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);


// MySQL bağlantısı
// MySQL Hostname
$sql_db_host = "localhost";
// MySQL Veritabanı Kullanıcı
$sql_db_user = "root"; //
// MySQL Veritabanı Şifresi
$sql_db_pass = "";
// MySQL Veritabanı Adı
$sql_db_name = "phpproje";

$site_url = 'localhost/esra_aytac/';
$sqlConnect   =  mysqli_connect($sql_db_host, $sql_db_user, $sql_db_pass, $sql_db_name, 3306);
// Hata listesi için array tanımı
$ServerErrors = array();
if (mysqli_connect_errno()) {
    $ServerErrors[] = "MySql bağlantısı başarısız: " . mysqli_connect_error();
}

if (isset($ServerErrors) && !empty($ServerErrors)) {

    // array içinde farklı hatalar varsa sırayla hepsini ekrana basıyoruz.
    foreach ($ServerErrors as $Error) {
        echo "<h3>" . $Error . "</h3>";
    }

    // eğer hata varsa sayfanın geri kalanını yüklemiyoruz
    die();
}


// Resim yüklemek için fonksiyon
function uploadImage($file, $targetDir = "uploads/") {
    // Dosya yükleme klasörünün var olup olmadığını kontrol et ve yoksa oluştur
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Dosya uzantısını al
    $fileExtension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

    // Benzersiz dosya adı oluştur
    $uniqueFileName = uniqid('img_', false) . '.' . $fileExtension;

    // Hedef dosya yolunu oluştur
    $targetFile = $targetDir . $uniqueFileName;

    // Dosyayı yükle
    if (move_uploaded_file($file["tmp_name"], $targetFile)) {
        return $targetFile;
    } else {
        return false;
    }
}


// sabit ayarları ismine göre güncellediğimiz fonksiyon
function UpdateConfig($update_name, $value) {
    global $sqlConnect;


    $value       = mysqli_real_escape_string($sqlConnect, $value);
    $query_one   = " UPDATE config SET `value` = '{$value}' WHERE `name` = '{$update_name}'";
    $query       = mysqli_query($sqlConnect, $query_one);
    if ($query) {
        return true;
    } else {
        return false;
    }
}


// sabit ayarlari ismine göre çektiğimiz fonksiyon
function GetConfig($name) {
    global $sqlConnect;
    if (empty($name)) {
        return false;
    }

    $sql_query_one = mysqli_query($sqlConnect, "SELECT * FROM config WHERE `name` = '$name'");
    if (mysqli_num_rows($sql_query_one)) {
        $fetched_data  = mysqli_fetch_assoc($sql_query_one);
        if (!empty($fetched_data)) {
            return $fetched_data;
        }
    }
    return false;
}


// projelerin tamamını çektiğimiz fonksiyon
function GetProjects(){
    global $sqlConnect;
    $query_one = "SELECT * FROM projects ORDER BY priority DESC";
    $sql       = mysqli_query($sqlConnect, $query_one);
    if (mysqli_num_rows($sql)) {
        while ($fetched_data = mysqli_fetch_assoc($sql)) {
            $data[]                    = $fetched_data;
        }
    }

    return $data;
}

// çalışanların tamamını çektiğimiz fonksiyon
function GetEmployees(){
    global $sqlConnect;
    $query_one = "SELECT * FROM employees ORDER BY priority DESC";
    $sql       = mysqli_query($sqlConnect, $query_one);
    if (mysqli_num_rows($sql)) {
        while ($fetched_data = mysqli_fetch_assoc($sql)) {
            $data[]                    = $fetched_data;
        }
    }

    return $data;
}

// iletişim formunu dolduranların tamamını çektiğimiz fonksiyon
function GetContacts(){
    global $sqlConnect;
    $query_one = "SELECT * FROM contacts ORDER BY id DESC";
    $sql       = mysqli_query($sqlConnect, $query_one);
    if (mysqli_num_rows($sql)) {
        while ($fetched_data = mysqli_fetch_assoc($sql)) {
            $data[]                    = $fetched_data;
        }
    }

    return $data;
}