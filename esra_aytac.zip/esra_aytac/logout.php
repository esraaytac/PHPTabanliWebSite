<?php
// logout.php

session_start();
session_unset();
session_destroy();
header("Refresh: 1; url=login.php");
exit();
?>
<!DOCTYPE html>
<html lang="tr-TR">
<head>
    <meta charset="utf-8"/>
    <title>Oturum Kapatma İşlemi</title>
</head>
<body>
    <p>Oturum kapatılıyor, lütfen bekleyin...</p>
</body>
</html>

