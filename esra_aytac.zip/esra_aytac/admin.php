

<?php
session_start();

include_once('init.php');

// eğer kullanıcı yoksa logine geri gönderiyoruz
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// admin header kısmı
include_once('admin/header.php');

$page_list = array(
    'dashboard',
    'add-project',
    'list-project',
    'add-personal',
    'list-personal',
    'list-contact',
    'edit-project',
    'edit-personal'
);

$page = 'dashboard';
// admin için sayfalama 
if (!empty($_GET['page'])) {
    $page = $_GET['page'];
}

// gelen page değerinin page liste olup olmadığını kontrol 
if (in_array($page, $page_list)) {
    $page_loaded = 'admin/'.$page.'.php';
    include_once($page_loaded);
}else {
    echo 'böyle bir sayfa bulunamadı';
}

// admin footer kısmı
include_once('admin/footer.php');
?>
