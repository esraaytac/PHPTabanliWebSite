-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 07 Haz 2024, 08:03:23
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `phpproje`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `name` varchar(155) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `config`
--

INSERT INTO `config` (`id`, `name`, `value`) VALUES
(1, 'firma_kisaltmasi', 'VY'),
(2, 'firma_org', 'VİZYON YAPI'),
(3, 'about', 'Vizyon Yapı, inşaat ve mimarlık alanında yenilikçi ve sürdürülebilir çözümler sunan bir firmadır. Profesyonel ekibimizle, estetik ve fonksiyonelliği bir araya getirerek, müşteri memnuniyetini en üst seviyede tutmayı hedefliyoruz. Projelerimizde kaliteli malzeme ve ileri teknolojiyi kullanarak, güvenli ve konforlu yaşam alanları yaratıyoruz. Bize güvenen müşterilerimizle birlikte büyümekten gurur duyuyoruz.'),
(4, 'firma_cover', 'uploads/img_6654970cd4fc6.jpg'),
(5, 'footer_cover', 'uploads/img_664aba6f759525.40214876.jpg'),
(6, 'footer_text', 'Esra Aytaç tarafından hazırlanmıştır.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(155) DEFAULT NULL,
  `email` varchar(155) DEFAULT NULL,
  `subject` varchar(155) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `registered_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `comment`, `registered_at`) VALUES
(9, 'Test', 'test@gmail.com', 'Test', 'test', '2024-05-20 13:12:13'),
(10, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:39:01'),
(11, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:46:27'),
(12, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:47:01'),
(13, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:47:17'),
(14, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:48:13'),
(15, 'ESRA AYTAÇ', 'esraaytac45@gmail.com', 'kış bahçesi tasarım', 'merhaba', '2024-05-27 18:48:41');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(155) DEFAULT NULL,
  `employee_pos` varchar(155) DEFAULT NULL,
  `employee_about` text DEFAULT NULL,
  `employee_pp` varchar(155) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `employees`
--

INSERT INTO `employees` (`id`, `employee_name`, `employee_pos`, `employee_about`, `employee_pp`, `priority`) VALUES
(3, 'Melike VİZYON', 'CEO & Founder', 'Şirket Yöneticisi', 'uploads/img_6654a275aec79.jpg', 11),
(4, 'Yıldırım BÜYÜK', 'İnşaat Mühendisi', 'Firmamızın önde gelen inşaat mühendisi', 'uploads/img_6654a7cc254e8.jpg', 10),
(8, 'Serenay SAĞLAM', 'Mimar', 'Firmamızın mimarı', 'uploads/img_6654a22c95677.jpg', 10),
(9, 'Turgay KAYA', 'İş güvenlik Uzmanı', '', 'uploads/img_6654a8e97135a.jpg', 10);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_name` varchar(155) DEFAULT NULL,
  `project_cover` varchar(155) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `projects`
--

INSERT INTO `projects` (`id`, `project_name`, `project_cover`, `priority`) VALUES
(7, 'Summer House', 'uploads/img_664b22647126f.jpg', 10),
(8, 'Brick House', 'uploads/img_664b2270d6653.jpg', 10),
(10, 'Modern House', 'uploads/img_6654979b087ac.jpg', 10),
(11, 'Sweet House', 'uploads/img_66549999cfca3.jpg', 10);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(55) DEFAULT NULL,
  `password` varchar(155) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'esra_aytac', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Tablo için AUTO_INCREMENT değeri `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
